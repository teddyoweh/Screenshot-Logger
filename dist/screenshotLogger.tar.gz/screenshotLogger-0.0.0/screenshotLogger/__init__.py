# -*- coding=utf-8 -*-
# Name: teddy oweh
# Email: teddyoweh@gmail.com
# Message: Feel Free To Contact Me on Enquires or Question, il Reply :)
from ScreenshotLogger.screenshotLogger import screenshotLogger